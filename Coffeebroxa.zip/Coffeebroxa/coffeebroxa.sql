-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 17/04/2024 às 15:57
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `coffeebroxa`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `titulo` varchar(50) DEFAULT NULL,
  `subtitulo` varchar(255) DEFAULT NULL,
  `imagem` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `banner`
--

INSERT INTO `banner` (`id`, `titulo`, `subtitulo`, `imagem`) VALUES
(2, 'Coffeebroxa', '', '17-04-2024-10-38-07-1.png'),
(3, 'Coffeebroxa', '', '17-04-2024-10-39-26-4.jpg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `nome` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `senha` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `telefone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `endereco` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `logo` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `icone` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `instagram` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `twitter` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `linkedin` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `facebook` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `youtube` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `cor` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `titulo_servicos` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subtitulo_servicos` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `titulo_trabalhos` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subtitulo_trabalhos` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `titulo_equipe` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subtitulo_equipe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `titulo_contato` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subtitulo_contato` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `texto_rodape` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `config`
--

INSERT INTO `config` (`id`, `nome`, `email`, `senha`, `telefone`, `endereco`, `logo`, `icone`, `instagram`, `twitter`, `linkedin`, `facebook`, `youtube`, `cor`, `titulo_servicos`, `subtitulo_servicos`, `titulo_trabalhos`, `subtitulo_trabalhos`, `titulo_equipe`, `subtitulo_equipe`, `titulo_contato`, `subtitulo_contato`, `texto_rodape`) VALUES
(1, 'CoffeeBroxa', 'admin@gmail.com', '123', '(11) 98765-4321', 'Rua broxa 200', 'logo.png', 'icone.png', 'Coffegroxa_', '', '', '', '', '#3333ff', NULL, NULL, NULL, NULL, NULL, NULL, 'Contate-nos', 'Preencha os Campos abaixo para entrar em contato conosco!', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `equipe`
--

CREATE TABLE `equipe` (
  `id` int(11) NOT NULL,
  `nome` int(50) NOT NULL,
  `cargo` int(50) NOT NULL,
  `imagem` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

CREATE TABLE `servicos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `video` varchar(100) DEFAULT NULL,
  `exibir` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `servicos`
--

INSERT INTO `servicos` (`id`, `titulo`, `descricao`, `imagem`, `video`, `exibir`) VALUES
(4, 'Café', '<div><span style=\"color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;\"=\"\">A produção do café na Coffeebroxa é cuidadosamente gerenciada desde a seleção dos grãos até a xícara final. A empresa valoriza a qualidade e a sustentabilidade em todas as etapas do processo.</span></div><div><i><span style=\"color: var(--tw-prose-bold); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;=\"\" border:=\"\" 0px=\"\" solid=\"\" rgb(227,=\"\" 227,=\"\" 227);=\"\" --tw-border-spacing-x:=\"\" 0;=\"\" --tw-border-spacing-y:=\"\" --tw-translate-x:=\"\" --tw-translate-y:=\"\" --tw-rotate:=\"\" --tw-skew-x:=\"\" --tw-skew-y:=\"\" --tw-scale-x:=\"\" 1;=\"\" --tw-scale-y:=\"\" --tw-pan-x:=\"\" ;=\"\" --tw-pan-y:=\"\" --tw-pinch-zoom:=\"\" --tw-scroll-snap-strictness:=\"\" proximity;=\"\" --tw-gradient-from-position:=\"\" --tw-gradient-via-position:=\"\" --tw-gradient-to-position:=\"\" --tw-ordinal:=\"\" --tw-slashed-zero:=\"\" --tw-numeric-figure:=\"\" --tw-numeric-spacing:=\"\" --tw-numeric-fraction:=\"\" --tw-ring-inset:=\"\" --tw-ring-offset-width:=\"\" 0px;=\"\" --tw-ring-offset-color:=\"\" #fff;=\"\" --tw-ring-color:=\"\" rgba(69,89,164,.5);=\"\" --tw-ring-offset-shadow:=\"\" 0=\"\" transparent;=\"\" --tw-ring-shadow:=\"\" --tw-shadow:=\"\" --tw-shadow-colored:=\"\" --tw-blur:=\"\" --tw-brightness:=\"\" --tw-contrast:=\"\" --tw-grayscale:=\"\" --tw-hue-rotate:=\"\" --tw-invert:=\"\" --tw-saturate:=\"\" --tw-sepia:=\"\" --tw-drop-shadow:=\"\" --tw-backdrop-blur:=\"\" --tw-backdrop-brightness:=\"\" --tw-backdrop-contrast:=\"\" --tw-backdrop-grayscale:=\"\" --tw-backdrop-hue-rotate:=\"\" --tw-backdrop-invert:=\"\" --tw-backdrop-opacity:=\"\" --tw-backdrop-saturate:=\"\" --tw-backdrop-sepia:=\"\" --tw-contain-size:=\"\" --tw-contain-layout:=\"\" --tw-contain-paint:=\"\" --tw-contain-style:=\"\" font-weight:=\"\" 600;\"=\"\">Seleção de Grãos:</span><span style=\"color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;\"=\"\"> A equipe da Coffeebroxa trabalha em estreita colaboração com produtores locais e internacionais para selecionar os melhores grãos. Eles priorizam fazendas que adotam práticas sustentáveis e éticas.</span></i></div><div><i><span style=\"color: var(--tw-prose-bold); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;=\"\" border:=\"\" 0px=\"\" solid=\"\" rgb(227,=\"\" 227,=\"\" 227);=\"\" --tw-border-spacing-x:=\"\" 0;=\"\" --tw-border-spacing-y:=\"\" --tw-translate-x:=\"\" --tw-translate-y:=\"\" --tw-rotate:=\"\" --tw-skew-x:=\"\" --tw-skew-y:=\"\" --tw-scale-x:=\"\" 1;=\"\" --tw-scale-y:=\"\" --tw-pan-x:=\"\" ;=\"\" --tw-pan-y:=\"\" --tw-pinch-zoom:=\"\" --tw-scroll-snap-strictness:=\"\" proximity;=\"\" --tw-gradient-from-position:=\"\" --tw-gradient-via-position:=\"\" --tw-gradient-to-position:=\"\" --tw-ordinal:=\"\" --tw-slashed-zero:=\"\" --tw-numeric-figure:=\"\" --tw-numeric-spacing:=\"\" --tw-numeric-fraction:=\"\" --tw-ring-inset:=\"\" --tw-ring-offset-width:=\"\" 0px;=\"\" --tw-ring-offset-color:=\"\" #fff;=\"\" --tw-ring-color:=\"\" rgba(69,89,164,.5);=\"\" --tw-ring-offset-shadow:=\"\" 0=\"\" transparent;=\"\" --tw-ring-shadow:=\"\" --tw-shadow:=\"\" --tw-shadow-colored:=\"\" --tw-blur:=\"\" --tw-brightness:=\"\" --tw-contrast:=\"\" --tw-grayscale:=\"\" --tw-hue-rotate:=\"\" --tw-invert:=\"\" --tw-saturate:=\"\" --tw-sepia:=\"\" --tw-drop-shadow:=\"\" --tw-backdrop-blur:=\"\" --tw-backdrop-brightness:=\"\" --tw-backdrop-contrast:=\"\" --tw-backdrop-grayscale:=\"\" --tw-backdrop-hue-rotate:=\"\" --tw-backdrop-invert:=\"\" --tw-backdrop-opacity:=\"\" --tw-backdrop-saturate:=\"\" --tw-backdrop-sepia:=\"\" --tw-contain-size:=\"\" --tw-contain-layout:=\"\" --tw-contain-paint:=\"\" --tw-contain-style:=\"\" font-weight:=\"\" 600;\"=\"\">Torrefação Artesanal:</span><span style=\"color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;\"=\"\"> Os grãos selecionados são torrados artesanalmente em lotes pequenos para garantir máxima frescura e sabor. A torrefação é um processo delicado, onde os mestres de torra ajustam cuidadosamente o tempo e a temperatura para realçar as características únicas de cada variedade de café.</span></i></div><div><i><span style=\"color: var(--tw-prose-bold); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;=\"\" border:=\"\" 0px=\"\" solid=\"\" rgb(227,=\"\" 227,=\"\" 227);=\"\" --tw-border-spacing-x:=\"\" 0;=\"\" --tw-border-spacing-y:=\"\" --tw-translate-x:=\"\" --tw-translate-y:=\"\" --tw-rotate:=\"\" --tw-skew-x:=\"\" --tw-skew-y:=\"\" --tw-scale-x:=\"\" 1;=\"\" --tw-scale-y:=\"\" --tw-pan-x:=\"\" ;=\"\" --tw-pan-y:=\"\" --tw-pinch-zoom:=\"\" --tw-scroll-snap-strictness:=\"\" proximity;=\"\" --tw-gradient-from-position:=\"\" --tw-gradient-via-position:=\"\" --tw-gradient-to-position:=\"\" --tw-ordinal:=\"\" --tw-slashed-zero:=\"\" --tw-numeric-figure:=\"\" --tw-numeric-spacing:=\"\" --tw-numeric-fraction:=\"\" --tw-ring-inset:=\"\" --tw-ring-offset-width:=\"\" 0px;=\"\" --tw-ring-offset-color:=\"\" #fff;=\"\" --tw-ring-color:=\"\" rgba(69,89,164,.5);=\"\" --tw-ring-offset-shadow:=\"\" 0=\"\" transparent;=\"\" --tw-ring-shadow:=\"\" --tw-shadow:=\"\" --tw-shadow-colored:=\"\" --tw-blur:=\"\" --tw-brightness:=\"\" --tw-contrast:=\"\" --tw-grayscale:=\"\" --tw-hue-rotate:=\"\" --tw-invert:=\"\" --tw-saturate:=\"\" --tw-sepia:=\"\" --tw-drop-shadow:=\"\" --tw-backdrop-blur:=\"\" --tw-backdrop-brightness:=\"\" --tw-backdrop-contrast:=\"\" --tw-backdrop-grayscale:=\"\" --tw-backdrop-hue-rotate:=\"\" --tw-backdrop-invert:=\"\" --tw-backdrop-opacity:=\"\" --tw-backdrop-saturate:=\"\" --tw-backdrop-sepia:=\"\" --tw-contain-size:=\"\" --tw-contain-layout:=\"\" --tw-contain-paint:=\"\" --tw-contain-style:=\"\" font-weight:=\"\" 600;\"=\"\">Moagem Personalizada:</span><span style=\"color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;\"=\"\"> Antes de serem servidos aos clientes, os grãos são moídos na hora, garantindo frescor e aroma intensos em cada xícara.</span></i></div><div><i><span style=\"color: var(--tw-prose-bold); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;=\"\" border:=\"\" 0px=\"\" solid=\"\" rgb(227,=\"\" 227,=\"\" 227);=\"\" --tw-border-spacing-x:=\"\" 0;=\"\" --tw-border-spacing-y:=\"\" --tw-translate-x:=\"\" --tw-translate-y:=\"\" --tw-rotate:=\"\" --tw-skew-x:=\"\" --tw-skew-y:=\"\" --tw-scale-x:=\"\" 1;=\"\" --tw-scale-y:=\"\" --tw-pan-x:=\"\" ;=\"\" --tw-pan-y:=\"\" --tw-pinch-zoom:=\"\" --tw-scroll-snap-strictness:=\"\" proximity;=\"\" --tw-gradient-from-position:=\"\" --tw-gradient-via-position:=\"\" --tw-gradient-to-position:=\"\" --tw-ordinal:=\"\" --tw-slashed-zero:=\"\" --tw-numeric-figure:=\"\" --tw-numeric-spacing:=\"\" --tw-numeric-fraction:=\"\" --tw-ring-inset:=\"\" --tw-ring-offset-width:=\"\" 0px;=\"\" --tw-ring-offset-color:=\"\" #fff;=\"\" --tw-ring-color:=\"\" rgba(69,89,164,.5);=\"\" --tw-ring-offset-shadow:=\"\" 0=\"\" transparent;=\"\" --tw-ring-shadow:=\"\" --tw-shadow:=\"\" --tw-shadow-colored:=\"\" --tw-blur:=\"\" --tw-brightness:=\"\" --tw-contrast:=\"\" --tw-grayscale:=\"\" --tw-hue-rotate:=\"\" --tw-invert:=\"\" --tw-saturate:=\"\" --tw-sepia:=\"\" --tw-drop-shadow:=\"\" --tw-backdrop-blur:=\"\" --tw-backdrop-brightness:=\"\" --tw-backdrop-contrast:=\"\" --tw-backdrop-grayscale:=\"\" --tw-backdrop-hue-rotate:=\"\" --tw-backdrop-invert:=\"\" --tw-backdrop-opacity:=\"\" --tw-backdrop-saturate:=\"\" --tw-backdrop-sepia:=\"\" --tw-contain-size:=\"\" --tw-contain-layout:=\"\" --tw-contain-paint:=\"\" --tw-contain-style:=\"\" font-weight:=\"\" 600;\"=\"\">Preparo Especializado:</span><span style=\"color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" font-size:=\"\" 1rem;\"=\"\"> Os baristas da Coffeebroxa são treinados para preparar cada café com habilidade e cuidado, seja uma simples xícara de espresso ou uma bebida mais elaborada. Eles estão sempre disponíveis para personalizar a bebida de acordo com as preferências individuais dos clientes.</span></i></div><div><i><span style=\"color: var(--tw-prose-bold); font-size: 1rem; font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;=\"\" border:=\"\" 0px=\"\" solid=\"\" rgb(227,=\"\" 227,=\"\" 227);=\"\" --tw-border-spacing-x:=\"\" 0;=\"\" --tw-border-spacing-y:=\"\" --tw-translate-x:=\"\" --tw-translate-y:=\"\" --tw-rotate:=\"\" --tw-skew-x:=\"\" --tw-skew-y:=\"\" --tw-scale-x:=\"\" 1;=\"\" --tw-scale-y:=\"\" --tw-pan-x:=\"\" ;=\"\" --tw-pan-y:=\"\" --tw-pinch-zoom:=\"\" --tw-scroll-snap-strictness:=\"\" proximity;=\"\" --tw-gradient-from-position:=\"\" --tw-gradient-via-position:=\"\" --tw-gradient-to-position:=\"\" --tw-ordinal:=\"\" --tw-slashed-zero:=\"\" --tw-numeric-figure:=\"\" --tw-numeric-spacing:=\"\" --tw-numeric-fraction:=\"\" --tw-ring-inset:=\"\" --tw-ring-offset-width:=\"\" 0px;=\"\" --tw-ring-offset-color:=\"\" #fff;=\"\" --tw-ring-color:=\"\" rgba(69,89,164,.5);=\"\" --tw-ring-offset-shadow:=\"\" 0=\"\" transparent;=\"\" --tw-ring-shadow:=\"\" --tw-shadow:=\"\" --tw-shadow-colored:=\"\" --tw-blur:=\"\" --tw-brightness:=\"\" --tw-contrast:=\"\" --tw-grayscale:=\"\" --tw-hue-rotate:=\"\" --tw-invert:=\"\" --tw-saturate:=\"\" --tw-sepia:=\"\" --tw-drop-shadow:=\"\" --tw-backdrop-blur:=\"\" --tw-backdrop-brightness:=\"\" --tw-backdrop-contrast:=\"\" --tw-backdrop-grayscale:=\"\" --tw-backdrop-hue-rotate:=\"\" --tw-backdrop-invert:=\"\" --tw-backdrop-opacity:=\"\" --tw-backdrop-saturate:=\"\" --tw-backdrop-sepia:=\"\" --tw-contain-size:=\"\" --tw-contain-layout:=\"\" --tw-contain-paint:=\"\" --tw-contain-style:=\"\" font-weight:=\"\" 600;\"=\"\">Sustentabilidade:</span><span style=\"font-size: 1rem; color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;\"=\"\"> A Coffeebroxa está comprometida com práticas sustentáveis em todas as etapas do processo, desde a fazenda até a xícara. Eles buscam reduzir o impacto ambiental através de iniciativas como o uso de grãos orgânicos, embalagens recicláveis e parcerias com fornecedores locais.</span></i><br></div>', '17-04-2024-09-51-31-sem-foto.jpg', '', 'Imagem');

-- --------------------------------------------------------

--
-- Estrutura para tabela `sobre`
--

CREATE TABLE `sobre` (
  `id` int(11) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `subtitulo` varchar(255) DEFAULT NULL,
  `descricao` text NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `video` varchar(100) DEFAULT NULL,
  `exibir` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `sobre`
--

INSERT INTO `sobre` (`id`, `titulo`, `subtitulo`, `descricao`, `imagem`, `video`, `exibir`) VALUES
(1, 'Coffeebroxa', 'Uma pequena cafeteria para um grande negocio ', '<p style=\"border: 0px solid rgb(227, 227, 227); --tw-border-spacing-x: 0; --tw-border-spacing-y: 0; --tw-translate-x: 0; --tw-translate-y: 0; --tw-rotate: 0; --tw-skew-x: 0; --tw-skew-y: 0; --tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgba(69,89,164,.5); --tw-ring-offset-shadow: 0 0 transparent; --tw-ring-shadow: 0 0 transparent; --tw-shadow: 0 0 transparent; --tw-shadow-colored: 0 0 transparent; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; margin-right: 0px; margin-bottom: 1.25em; margin-left: 0px; color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;\"=\"\"><span style=\"font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;\"=\"\">Na Coffeebroxa, os clientes são recebidos por uma atmosfera acolhedora, com aroma de café fresco no ar. O ambiente é aconchegante, com móveis confortáveis e espaçados para privacidade. A decoração inclui obras de arte local, criando um ambiente culturalmente rico. A equipe é hospitaleira e conhecedora, pronta para recomendar blends de café e compartilhar histórias fascinantes. É um refúgio sereno para os amantes do café, onde cada gole é saboreado em tranquilidade.</span><br></p><p style=\"border: 0px solid rgb(227, 227, 227); --tw-border-spacing-x: 0; --tw-border-spacing-y: 0; --tw-translate-x: 0; --tw-translate-y: 0; --tw-rotate: 0; --tw-skew-x: 0; --tw-skew-y: 0; --tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgba(69,89,164,.5); --tw-ring-offset-shadow: 0 0 transparent; --tw-ring-shadow: 0 0 transparent; --tw-shadow: 0 0 transparent; --tw-shadow-colored: 0 0 transparent; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; margin: 1.25em 0px; color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;\"=\"\">A equipe da Coffeebroxa é conhecida pela sua hospitalidade calorosa e conhecimento apaixonado sobre café. Eles estão sempre prontos para recomendar o blend perfeito para satisfazer os gostos individuais de cada cliente e estão felizes em compartilhar histórias fascinantes sobre a origem e o processo de produção dos grãos.</p><p style=\"border: 0px solid rgb(227, 227, 227); --tw-border-spacing-x: 0; --tw-border-spacing-y: 0; --tw-translate-x: 0; --tw-translate-y: 0; --tw-rotate: 0; --tw-skew-x: 0; --tw-skew-y: 0; --tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgba(69,89,164,.5); --tw-ring-offset-shadow: 0 0 transparent; --tw-ring-shadow: 0 0 transparent; --tw-shadow: 0 0 transparent; --tw-shadow-colored: 0 0 transparent; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; margin: 1.25em 0px 0px; color: rgb(13, 13, 13); font-family: Söhne, ui-sans-serif, system-ui, -apple-system, \" segoe=\"\" ui\",=\"\" roboto,=\"\" ubuntu,=\"\" cantarell,=\"\" \"noto=\"\" sans\",=\"\" sans-serif,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" emoji\";=\"\" white-space-collapse:=\"\" preserve;\"=\"\">Em suma, a Coffeebroxa é mais do que uma simples cafeteria; é um santuário para os amantes do café, um lugar onde o tempo desacelera e os momentos são saboreados com cada gole.</p>', '17-04-2024-09-29-07-2.jpg', '', 'Imagem');

-- --------------------------------------------------------

--
-- Estrutura para tabela `trabalhos`
--

CREATE TABLE `trabalhos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `imagem` varchar(100) NOT NULL,
  `video` varchar(100) DEFAULT NULL,
  `exibir` varchar(20) NOT NULL,
  `link` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `trabalhos`
--

INSERT INTO `trabalhos` (`id`, `titulo`, `descricao`, `imagem`, `video`, `exibir`, `link`) VALUES
(1, 'café com sorvetão', 'um café levemente amargo acompanhando com um leve gosto açucarado de duas bolas de sorvete de creme', '17-04-2024-09-47-15-5.png', '', 'Imagem', '');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `equipe`
--
ALTER TABLE `equipe`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `sobre`
--
ALTER TABLE `sobre`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `trabalhos`
--
ALTER TABLE `trabalhos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `equipe`
--
ALTER TABLE `equipe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `servicos`
--
ALTER TABLE `servicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `sobre`
--
ALTER TABLE `sobre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `trabalhos`
--
ALTER TABLE `trabalhos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
